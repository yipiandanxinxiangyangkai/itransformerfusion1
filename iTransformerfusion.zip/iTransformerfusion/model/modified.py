import torch
import torch.nn as nn

class TemporalVectorFuser(nn.Module):
    """
    一个在每个时间步上，使用Transformer软融合两个5D向量的模型。
    
    输入:
        - x_text: [Batch, Time, 5] (文本向量)
        - x_fin:  [Batch, Time, 5] (金融向量)
    输出:
        - prediction: [Batch, 1] (预测的股价)
    """
    def __init__(self, seq_len, embed_dim=5, num_heads=1, dim_feedforward=32, dropout=0.1, mlp_dim=64):
        super(TemporalVectorFuser, self).__init__()
        
        self.seq_len = seq_len
        self.embed_dim = embed_dim # 也就是你的向量维度 5
        
        # 1. [CLS] Token
        # 这个Token将用于学习"融合"两个向量后的表示
        # 它的维度也是 embed_dim (5)
        self.cls_token = nn.Parameter(torch.randn(1, 1, embed_dim))
        
        # 2. 融合层 (一个标准的Transformer编码器层)
        # 它将在(文本, 金融, CLS)这3个Token之间计算注意力
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=embed_dim, 
            nhead=num_heads,
            dim_feedforward=dim_feedforward,
            dropout=dropout,
            batch_first=True  # 确保输入是 [Batch, Seq, Feature]
        )
        self.fusion_encoder = nn.TransformerEncoder(encoder_layer, num_layers=1)
        
        # 3. 最终的预测MLP
        # 输入是融合后的时间序列 (被展平)
        # 或者，我们可以只用最后一个时间步的融合向量
        # 让我们使用更简单的方式：只用最后一个时间步
        self.final_mlp = nn.Sequential(
            nn.Linear(embed_dim, mlp_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(mlp_dim, 1) # 最终预测一个值
        )

    def forward(self, x_text, x_fin):
        # x_text: [B, T, 5]
        # x_fin:  [B, T, 5]
        
        B, T, E = x_text.shape  # B, T, 5
        
        # 1. 堆叠：将两个向量在"Token"维度上堆叠
        # [B, T, 5] 和 [B, T, 5] -> [B, T, 2, 5]
        x_stacked = torch.stack([x_text, x_fin], dim=2)
        
        # 2. 变形 (Batch * Time)
        # 我们希望在T的维度上并行处理
        # [B, T, 2, 5] -> [B*T, 2, 5]
        # 现在我们有 B*T 个"批次"，每个批次有 2 个 Token (文本, 金融)，每个Token 5 维
        x_reshaped = x_stacked.reshape(B * T, 2, E)
        
        # 3. 添加 [CLS] Token
        # cls_token: [1, 1, 5] -> [B*T, 1, 5]
        cls_tokens = self.cls_token.expand(B * T, -1, -1)
        
        # x_with_cls: [B*T, 3, 5] (Token序列: CLS, 文本, 金融)
        x_with_cls = torch.cat([cls_tokens, x_reshaped], dim=1)
        
        # 4. 逐时间步融合
        # Transformer Encoder 将在这 3 个 Token 间计算注意力
        # fused_output: [B*T, 3, 5]
        fused_output = self.fusion_encoder(x_with_cls)
        
        # 5. 提取融合后的表示
        # 我们只关心 [CLS] Token 的输出，因为它已经"看"过了文本和金融
        # fused_vec: [B*T, 5]
        fused_vec = fused_output[:, 0, :] # 取第0个Token (CLS)
        
        # 6. 还原时间维度
        # fused_series: [B, T, 5]
        # 这就是你想要的 "软融合成一个5维向量" 后的 **时间序列**
        fused_series = fused_vec.reshape(B, T, E)
        
        # 7. 预测
        # 我们使用融合后序列的 **最后一个时间步** 的向量来进行预测
        # last_step_vec: [B, 5]
        last_step_vec = fused_series[:, -1, :]
        
        # prediction: [B, 1]
        prediction = self.final_mlp(last_step_vec)
        
        return prediction