# (确保你已经 import 了所有你提供的类)
from layers.Embed import DataEmbedding 
from layers.Transformer_EncDec import DecoderLayer
# ... etc.

class TextStockFusionModel(nn.Module):
    def __init__(self, configs):
        super(TextStockFusionModel, self).__init__()
        
        self.d_model = configs.d_model

        # --- 1. 文本嵌入层 (将 "数据" 转为 "向量") ---
        self.text_token_embedding = nn.Embedding(configs.vocab_size, configs.d_model)
        self.text_pos_embedding = PositionalEmbedding(configs.d_model)

        # --- 2. 股价嵌入层 (将 "数据" 转为 "向量") ---
        # 复用你提供的 DataEmbedding
        self.stock_embedding = DataEmbedding(
            c_in=configs.stock_c_in, 
            d_model=configs.d_model, 
            embed_type=configs.embed_type, 
            freq=configs.freq,
            dropout=configs.dropout
        )

        # --- 3. 融合层 (处理 "向量") ---
        self.fusion_layer = DecoderLayer(
            # (self-attention for text)
            AttentionLayer(...),
            # (cross-attention for text-querying-stock)
            AttentionLayer(...),
            # ... (其他 DecoderLayer 参数)
        )
        
        # --- 4. 输出层 ---
        self.output_projection = nn.Linear(configs.d_model, configs.output_dim)


    def forward(self, text_token_ids, stock_values, stock_time_marks):
        """
        模型的 "入口" 在这里！
        
        Args:
            text_token_ids (Tensor): 文本 "数据" (Token IDs)
                                     形状: [B, L_text] (Long)
            stock_values (Tensor):   股价 "数据" (OHLC values)
                                     形状: [B, L_stock, stock_c_in] (Float)
            stock_time_marks (Tensor): 股价时间 "数据" (Time features)
                                       形状: [B, L_stock, time_features] (Float or Long)
        """
        
        # 1. 处理文本: [B, L_text] -> [B, L_text, D_model] (向量)
        text_emb = self.text_token_embedding(text_token_ids) + self.text_pos_embedding(text_token_ids)
        
        # 2. 处理股价: [B, L_stock, c_in] -> [B, L_stock, D_model] (向量)
        stock_emb = self.stock_embedding(stock_values, stock_time_marks)

        # 3. 执行融合 (交叉注意力)
        # Q = text_emb (向量), K/V = stock_emb (向量)
        fused_output, cross_attn = self.fusion_layer(
            x=text_emb,      
            cross=stock_emb,  
            x_mask=None,
            cross_mask=None
        )

        # 4. 产生最终输出 (一段向量)
        final_vector_pooled = fused_output.mean(dim=1) # [B, D_model]
        final_output = self.output_projection(final_vector_pooled) # [B, output_dim]
        
        return final_output